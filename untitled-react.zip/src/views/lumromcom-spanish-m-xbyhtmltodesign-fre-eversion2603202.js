import React from 'react'

import { Helmet } from 'react-helmet'

import './lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202.css'

const LumromcomSpanishMXbyhtmltodesignFREEversion2603202 = (props) => {
  return (
    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-container1">
      <Helmet>
        <title>exported project</title>
        <meta property="og:title" content="exported project" />
        <link rel="canonical" href="https://untitled-tjuc3o.teleporthq.app/" />
        <meta
          property="og:url"
          content="https://untitled-tjuc3o.teleporthq.app/"
        />
      </Helmet>
      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-elm">
        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-frame1920wlight-elm">
          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divroot-elm">
            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-main-elm">
              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divcontainer-elm1">
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divimageabsoluteheader-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-homeheaderd3aa3091ce6a751a6c78png-elm"></div>
                </div>
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divsection1-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1-elm1">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm10">
                      <span>TRANSPORTE DE CARGA</span>
                      <br></br>
                      <span>&amp; MOTOENTREGA</span>
                    </span>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h2-elm1">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm13">
                      Lleva lo que necesites:
                    </span>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbtn1-elm">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm14">
                      juguetes
                    </span>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-spancursor-elm"></div>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h2-elm2">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm15">
                      <span>de forma rápida y sin</span>
                      <br></br>
                      <span>complicaciones</span>
                    </span>
                  </div>
                </div>
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divsection2-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1mb3margin-elm">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm18">
                      Tipos de entrega
                    </span>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbox-elm1">
                    <img
                      src="/imagebefore123-lrgm-600w.png"
                      alt="IMAGEbefore123"
                      className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm10"
                    />
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divdeliverytypeselectormargin-elm">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divdeliverytypeselector-elm">
                        <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-buttondeliverytypebtn-elm1">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-apie-elm"></div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-span-elm1">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm19">
                              A pie
                            </span>
                          </div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-small-elm1">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm20">
                              (hasta 10 kg)
                            </span>
                          </div>
                        </button>
                        <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-buttondeliverytypebtn-elm2">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-enmoto-elm"></div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-span-elm2">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm21">
                              En moto
                            </span>
                          </div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-small-elm2">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm22">
                              (hasta 500 kg)
                            </span>
                          </div>
                        </button>
                        <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-buttondeliverytypebtn-elm3">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-encamin-elm"></div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-span-elm3">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm23">
                              En camión
                            </span>
                          </div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-small-elm3">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm24">
                              (hasta 3.5 t)
                            </span>
                          </div>
                        </button>
                      </div>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divrowmargin-elm">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divrow-elm">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divcol-elm1">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-div-elm1">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm25">
                              Desde (dirección)
                            </span>
                            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-inputformcontrol-elm1">
                              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divplaceholder-elm1">
                                <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm26">
                                  Desde (dirección)
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divcol-elm2">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-div-elm2">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm27">
                              Hasta (dirección)
                            </span>
                            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-inputformcontrol-elm2">
                              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divplaceholder-elm2">
                                <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm28">
                                  Hasta (dirección)
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbuttonmargin-elm">
                      <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbutton-elm">
                        <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-buttonbtn3-elm1">
                          <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm29">
                            Calcular el valor
                          </span>
                        </button>
                      </button>
                    </button>
                  </div>
                </div>
              </div>
              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divp0-elm">
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divsection4-elm">
                  <img
                    src="/imagebefore164-qp9e-1000w.png"
                    alt="IMAGEbefore164"
                    className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm11"
                  />
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbox-elm2">
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divimage-elm">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-g1021120fbab8e3b4508b1cpng-elm"></div>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divcontent-elm1">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1margin-elm1">
                        <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm30">
                          <span>Descubre las</span>
                          <br></br>
                          <span>ventajas de</span>
                          <br></br>
                          <span>trabajar con</span>
                          <br></br>
                          <span>nosotros</span>
                        </span>
                      </div>
                      <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-buttonbtn3-elm2">
                        <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm35">
                          Calcular el valor
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divsection6-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divlogo-elm">
                    <img
                      src="/imagebefore175-anm-400h.png"
                      alt="IMAGEbefore175"
                      className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm12"
                    />
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-logo6ea0dccb303e2b713b52png-elm"></div>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divcontent-elm2">
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1margin-elm2">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1-elm2">
                        <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm36">
                          Sobre nosotros
                        </span>
                      </div>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divtitlemargin-elm">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divtitle-elm">
                        <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm37">
                          <span>
                            Somos un equipo joven de Ecuador, unidos por el amor
                            a
                          </span>
                          <br></br>
                          <span>
                            nuestro país y el deseo de impulsarlo hacia el
                            futuro.
                          </span>
                        </span>
                      </div>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divdesc-elm1">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm40">
                        <span>
                          Creemos firmemente que la tecnología puede transformar
                          nuestro día
                        </span>
                        <br></br>
                        <span>
                          a día y contribuir al crecimiento y bienestar de
                          nuestra sociedad.
                        </span>
                        <br></br>
                        <span>
                          Ecuador no solo es tierra de belleza natural y cultura
                          vibrante —
                        </span>
                        <br></br>
                        <span>también es un país lleno de potencial.</span>
                      </span>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divdesc-elm2">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm45">
                        <span>
                          Con soluciones innovadoras queremos apoyar a los
                          negocios locales,
                        </span>
                        <br></br>
                        <span>
                          generar empleo y ser parte de un futuro más próspero
                          para todos.
                        </span>
                      </span>
                    </div>
                  </div>
                  <img
                    src="/imagebefore188-gty-400h.png"
                    alt="IMAGEbefore188"
                    className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm13"
                  />
                </div>
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divsection5-elm">
                  <img
                    src="/imagebefore190-dlna-400h.png"
                    alt="IMAGEbefore190"
                    className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm14"
                  />
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1margin-elm3">
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1-elm3">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm48">
                        ¿Cómo 
                      </span>
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm49">
                        funciona?
                      </span>
                    </div>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divcomponentgrid-elm">
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divcenterimage-elm">
                      <img
                        src="/imagebefore197-a8uq-400h.png"
                        alt="IMAGEbefore197"
                        className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm15"
                      />
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-central-elm"></div>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divleftitems-elm">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divgriditem-elm1">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-div-elm3">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h3itemtitle-elm1">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm50">
                              Elige la ciudad
                            </span>
                          </div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-pitemdesc-elm1">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm51">
                              <span>Operamos dentro de las</span>
                              <br></br>
                              <span>principales ciudades. Solo</span>
                              <br></br>
                              <span>selecciona la que necesitas</span>
                            </span>
                          </div>
                        </div>
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitemnumber-elm1">
                          <img
                            src="/imagebefore1107-7x2a-200h.png"
                            alt="IMAGEbefore1107"
                            className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm16"
                          />
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divgriditem-elm2">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-div-elm4">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h3itemtitle-elm2">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm55">
                              Realiza tu pedido
                            </span>
                          </div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-pitemdesc-elm2">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm56">
                              <span>¡Listo! El conductor se pondrá</span>
                              <br></br>
                              <span>en contacto contigo</span>
                            </span>
                          </div>
                        </div>
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitemnumber-elm2">
                          <img
                            src="/imagebefore1116-yu4m-200h.png"
                            alt="IMAGEbefore1116"
                            className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm17"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divrightitems-elm">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divgriditem-elm3">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-div-elm5">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h3itemtitle-elm3">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm59">
                              Calcula el precio
                            </span>
                          </div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-pitemdesc-elm3">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm60">
                              <span>Ingresa las direcciones de</span>
                              <br></br>
                              <span>origen y destino — nuestro</span>
                              <br></br>
                              <span>sistema te dará el costo</span>
                            </span>
                          </div>
                        </div>
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitemnumber-elm3">
                          <img
                            src="/imagebefore1126-5o0g-200h.png"
                            alt="IMAGEbefore1126"
                            className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm18"
                          />
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divgriditem-elm4">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-div-elm6">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h3itemtitle-elm4">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm64">
                              Recibe la confirmación
                            </span>
                          </div>
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-pitemdesc-elm4">
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm65">
                              <span>Te enviaremos un SMS con el</span>
                              <br></br>
                              <span>número del pedido y el</span>
                              <br></br>
                              <span>contacto del conductor</span>
                            </span>
                          </div>
                        </div>
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitemnumber-elm4">
                          <img
                            src="/imagebefore1135-98eq-200h.png"
                            alt="IMAGEbefore1135"
                            className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm19"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbottomitem-elm">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbottomnumbermargin-elm">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbottomnumber-elm">
                          <img
                            src="/imagebefore1141-bihs-200h.png"
                            alt="IMAGEbefore1141"
                            className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm20"
                          />
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divbottomcontent-elm">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h3bottomtitle-elm">
                          <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm69">
                            Pago directo al conductor
                          </span>
                        </div>
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-pbottomdesc-elm">
                          <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm70">
                            <span>Paga en efectivo al recibir el</span>
                            <br></br>
                            <span>servicio. Sin comisiones ni cargos</span>
                            <br></br>
                            <span>extra</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divsection3-elm">
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divtextcenter-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1margin-elm4">
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-h1-elm4">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm74">
                        <span>¿Qué se puede enviar</span>
                        <br></br>
                        <span>por mensajería?</span>
                      </span>
                    </div>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiper-elm">
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperwrapper-elm">
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslidemargin-elm1">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslide-elm1">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitem-elm1">
                            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divicon-elm1">
                              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-muebles-elm"></div>
                            </div>
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm77">
                              Muebles
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslidemargin-elm2">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslide-elm2">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitem-elm2">
                            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divicon-elm2">
                              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-juguetes-elm"></div>
                            </div>
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm78">
                              Juguetes
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslidemargin-elm3">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslide-elm3">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitem-elm3">
                            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divicon-elm3">
                              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-electrodomsticos-elm"></div>
                            </div>
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm79">
                              Electrodomésticos
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslidemargin-elm4">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslide-elm4">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitem-elm4">
                            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divicon-elm4">
                              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-productos-elm"></div>
                            </div>
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm80">
                              Productos
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslidemargin-elm5">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslide-elm5">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitem-elm5">
                            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divicon-elm5">
                              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-documentos-elm"></div>
                            </div>
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm81">
                              Documentos
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslidemargin-elm6">
                        <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslide-elm6">
                          <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divitem-elm6">
                            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divicon-elm6">
                              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-comidaderestaurantes-elm"></div>
                            </div>
                            <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm82">
                              Comida de restaurantes
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslidemargin-elm7"></div>
                      <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperslidemargin-elm8"></div>
                    </div>
                    <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperbuttonprev-elm">
                      <img
                        src="/frame1193-9nt4.svg"
                        alt="Frame1193"
                        className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-frame-elm1"
                      />
                    </button>
                    <button className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divswiperbuttonnext-elm">
                      <img
                        src="/frame1196-3slg.svg"
                        alt="Frame1196"
                        className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-frame-elm2"
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-header-elm">
              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divcontainer-elm2">
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-alogo-elm">
                  <img
                    src="/imagebefore1201-pr-300h.png"
                    alt="IMAGEbefore1201"
                    className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-imag-ebefore-elm21"
                  />
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-logo-elm"></div>
                </div>
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divheadermenumargin-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divheadermenu-elm">
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-ame2margin-elm1">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm83">
                        Calcular envío
                      </span>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-ame2margin-elm2">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm84">
                        Para empresas
                      </span>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-ame2margin-elm3">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm85">
                        Conviértete en conductor
                      </span>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-ame2margin-elm4">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm86">
                        Iniciar sesión
                      </span>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-a-elm1">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm87">
                        Registrarse
                      </span>
                    </div>
                    <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-spancityselectormargin-elm">
                      <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm88">
                        Ciudad
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-footer-elm">
              <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divfootercontent-elm">
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divfootercontacts-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divphone-elm">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm89">
                      +593 983 688 183
                    </span>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divemail-elm">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm90">
                      transporteslumrom@gmail.com
                    </span>
                  </div>
                </div>
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divfooterlogo-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-lumer-cargo-logo-elm"></div>
                </div>
                <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-divfooterlinks-elm">
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-a-elm2">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm91">
                      Principal
                    </span>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-a-elm3">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm92">
                      Tipos de entrega
                    </span>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-a-elm4">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm93">
                      Calcular el valor
                    </span>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-a-elm5">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm94">
                      Ventajas
                    </span>
                  </div>
                  <div className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-a-elm6">
                    <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-thq-text-elm95">
                      Acuerdo de usuario
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a
        href="https://play.teleporthq.io/signup"
        className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-link"
      >
        <div
          aria-label="Sign up to TeleportHQ"
          className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-container2"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="lumromcom-spanish-m-xbyhtmltodesign-fre-eversion2603202-text30">
            Built in TeleportHQ
          </span>
        </div>
      </a>
    </div>
  )
}

export default LumromcomSpanishMXbyhtmltodesignFREEversion2603202
